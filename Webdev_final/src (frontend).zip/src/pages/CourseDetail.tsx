import { useState, useEffect } from 'react';
import { useParams, useNavigate} from 'react-router-dom';
import {Book, Clock, Users, PlayCircle, CheckCircle, Lock } from 'lucide-react';
import './HomeTheme.css';
import api from '../api';
import ThemeToggleButton from '../components/ThemeToggleButton';
import Navbar from '../components/Navbar';
import { useCart } from '../contexts/CartContext';
import OceanAnimations from '../components/OceanAnimations';
import BackButton from '../components/BackButton';
import { useTheme } from '../contexts/ThemeContext';
import './OceanTheme.css';
import { getImageUrl } from '../utils/getImageUrl';

// 📌 Types
interface Lesson {
  lesson_id: number;
  title: string;
  sequence: number;
  video_url?: string;
  attachment_url?: string;
}

interface CourseDetailData {
  course_id: number;
  title: string;
  description: string;
  price: number;
  duration_weeks: number;
  cover_image_url?: string;
  level?: {
    level_name: string;
  };
  instructor?: {
    name: string;
    profile_image_url: string;
    bio: string;
  };
}

export default function CourseDetail() {
  const { theme } = useTheme();
  const { id } = useParams();
  const navigate = useNavigate();
  const { addToCart } = useCart();

  // 📌 States
  const [course, setCourse] = useState<CourseDetailData | null>(null);
  const [lessons, setLessons] = useState<Lesson[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  // 🌟 ดึงข้อมูลจาก API
  useEffect(() => {
    const fetchCourseDetail = async () => {
      try {
        setLoading(true);
        const courseRes = await api.get(`/courses/${id}`);
        setCourse(courseRes.data);
      } catch (err) {
        console.error('Error fetching course details:', err);
        setError('ไม่สามารถโหลดข้อมูลคอร์สได้ กรุณาลองใหม่อีกครั้ง');
      } finally {
        setLoading(false);
      }

      // ดึงบทเรียนแยก — ถ้า 403 (ยังไม่ login หรือยังไม่จ่ายเงิน) ให้ใช้ empty array แทน
      try {
        const lessonsRes = await api.get(`/lessons/course/${id}`);
        const lessonsData = Array.isArray(lessonsRes.data) ? lessonsRes.data : [];
        setLessons(lessonsData.sort((a: Lesson, b: Lesson) => a.sequence - b.sequence));
      } catch {
        setLessons([]);
      }
    };

    if (id) fetchCourseDetail();
  }, [id]);

  if (loading) return <div className="state-message" style={{ textAlign: 'center', padding: '100px', fontSize: '1.2rem' }}>กำลังโหลดข้อมูลคอร์สเรียน... ⏳</div>;

  if (error || !course) return (
    <div className="state-message" style={{ textAlign: 'center', padding: '100px' }}>
      <p style={{ color: 'red', fontSize: '1.2rem', marginBottom: '20px' }}>{error || 'ไม่พบคอร์สเรียน'}</p>
      <button className="btn-learn review" onClick={() => navigate(-1)} style={{ padding: '10px 20px', cursor: 'pointer' }}>กลับไปก่อนหน้า</button>
    </div>
  );

  return (
    <div className={`page-wrapper ${theme === 'ocean' ? 'ocean-page' : ''}`}>
      <Navbar />

      {/* 🔵 Header Section */}
      <header className="page-header page-header-sm">
        <OceanAnimations />
        <div className="container">
          <BackButton />
          <div className="cd-banner-content">
            <div className="cd-banner-info">
              <div className="cd-tags">
                <span className="cd-tag white-bg">{course.level?.level_name || 'ทั่วไป'}</span>
              </div>
              <h1 className="cd-title">{course.title}</h1>
              <p className="cd-subtitle">{course.description}</p>

              <div className="cd-stats-top">
                <div className="cd-stat-item"><Users size={18} /> 128 คนเรียนแล้ว</div>
                <div className="cd-stat-item"><Clock size={18} /> {course.duration_weeks > 0 ? `${course.duration_weeks} สัปดาห์` : 'ไม่ระบุระยะเวลา'}</div>
              </div>

              <div className="cd-instructor-badge">
                <div>
                  <span className="cd-instructor-name">สอนโดย: {course.instructor?.name || 'ไม่ระบุชื่อผู้สอน'}</span>
                  <span className="cd-instructor-sub">{course.instructor?.bio}</span>
                </div>
              </div>
            </div>

            <div className="cd-banner-video">
              <img src={getImageUrl(course.cover_image_url)} alt={course.title} />
            </div>
          </div>
        </div>
      </header>

      {/* ⚪️ Main Content */}
      <main className="section">
        <div className="container">
          <div className="cd-main-content">

            {/* Left: Syllabus & Details */}
            <div className="cd-left-column">
              <div className="cd-card">
                <h2 className="cd-card-title">รายละเอียดคอร์ส</h2>
                <div className="cd-feature-list">
                  <FeatureItem title="เรียนรู้แบบทีละขั้นตอน" desc="เนื้อหาครอบคลุมตามหลักสูตร จัดเรียงลำดับอย่างเป็นระบบ" />
                  <FeatureItem title="วิดีโอคุณภาพสูง" desc="ความละเอียดชัดเจน ดูได้ทุกอุปกรณ์" />
                  <FeatureItem title="ดูซ้ำได้ไม่จำกัด" desc="เข้าเรียนได้ตลอดเวลา ไม่มีวันหมดอายุ" />
                </div>
              </div>

              <div className="cd-card">
                <h2 className="cd-card-title">เนื้อหาในคอร์ส (Syllabus)</h2>
                {lessons.length > 0 ? (
                  <>
                    <p style={{ fontSize: '13px', color: '#64748b', marginBottom: '16px', display: 'flex', alignItems: 'center', gap: '6px' }}>
                      <Lock size={13} color="#f59e0b" />
                      เนื้อหาจะปลดล็อกหลังจากชำระเงินและยืนยันการลงทะเบียนเรียบร้อยแล้ว
                    </p>
                    <div className="cd-lesson-list">
                      {lessons.map((lesson) => (
                        <div
                          key={lesson.lesson_id}
                          className="cd-lesson-item"
                          style={{
                            cursor: 'not-allowed',
                            opacity: 0.85,
                            backgroundColor: '#f8fafc',
                            borderRadius: '8px',
                            padding: '12px 14px',
                            marginBottom: '8px',
                            border: '1px solid #e2e8f0',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'space-between',
                          }}
                          title="ชำระเงินและยืนยันการลงทะเบียนก่อนเข้าเรียน"
                        >
                          <div className="cd-lesson-name" style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                            <span style={{
                              width: '26px', height: '26px', borderRadius: '50%',
                              backgroundColor: '#e2e8f0', color: '#94a3b8',
                              display: 'flex', alignItems: 'center', justifyContent: 'center',
                              fontSize: '12px', fontWeight: 'bold', flexShrink: 0
                            }}>
                              {lesson.sequence}
                            </span>
                            <span style={{ fontSize: '14px', color: '#334155', fontWeight: 500 }}>
                              {lesson.title}
                            </span>
                          </div>
                          <div style={{ display: 'flex', alignItems: 'center', gap: '6px', color: '#94a3b8', fontSize: '12px' }}>
                            {lesson.video_url
                              ? <PlayCircle size={14} color="#cbd5e1" />
                              : null}
                            <Lock size={14} color="#f59e0b" />
                          </div>
                        </div>
                      ))}
                    </div>
                    <div style={{
                      marginTop: '12px', padding: '12px 16px', borderRadius: '8px',
                      backgroundColor: '#fffbeb', border: '1px solid #fde68a',
                      display: 'flex', alignItems: 'center', gap: '8px',
                      fontSize: '13px', color: '#92400e'
                    }}>
                      <Lock size={15} color="#f59e0b" />
                      <span>บทเรียนทั้งหมด <strong>{lessons.length} บท</strong> — ปลดล็อกได้หลังลงทะเบียนและชำระเงินแล้ว</span>
                    </div>
                  </>
                ) : (
                  <div className="empty-state">ยังไม่มีข้อมูลบทเรียนในขณะนี้</div>
                )}
              </div>
            </div>

            {/* Right: Pricing Card */}
            <div className="cd-right-column">
              <div className="cd-price-card">
                <h1 className="cd-price-amount">
                  {course.price > 0 ? `฿${course.price.toLocaleString()}` : 'เรียนฟรี'}
                </h1>
                <p className="cd-price-subtitle">จ่ายครั้งเดียว เข้าถึงเนื้อหาได้ตลอดไป</p>
                <button 
                  className="cd-enroll-bag"
                  onClick={async () => {
                    console.log('🛒 ปุ่มถูกกด!');
                    console.log('course_id:', course.course_id);
                    const result = await addToCart(course.course_id);
                    console.log('ผลลัพธ์:', result);
                  }}
                >
                  + เพิ่มลงในตะกร้า
                </button>
                <button className="cd-enroll-btn" onClick={() => navigate(`/payment/${course.course_id}`)}>
                  ลงทะเบียนเรียนเลย
                </button>
                <div className="cd-course-includes">
                  <div className="cd-include-item"><Book size={18} color="#3b82f6" /> {lessons.length} บทเรียน</div>
                  <div className="cd-include-item"><Clock size={18} color="#3b82f6" /> ระยะเวลา {course.duration_weeks > 0 ? `${course.duration_weeks} สัปดาห์` : 'ไม่ระบุ'}</div>
                </div>
              </div>
            </div>

          </div>
        </div>
      </main>

      {/* ================= Footer ================= */}
      <footer className="footer">
        <div className="container">
          <div className="footer-grid">
            <div>
              <h3>เกี่ยวกับเรา</h3>
              <p>New Learning Academy เป็นแพลตฟอร์มการเรียนรู้<br />ออนไลน์ชั้นนำ มุ่งเน้นพัฒนาศักยภาพผู้เรียน</p>
            </div>
            <div>
              <h3>ติดต่อเรา</h3>
              <p>อีเมล: info@newlearning.com</p>
              <p>โทร: 02-123-4567</p>
            </div>
            <div>
              <h3>เวลาทำการ</h3>
              <p>จันทร์ - ศุกร์: 09:00 - 18:00</p>
              <p>เสาร์ - อาทิตย์: 10:00 - 16:00</p>
            </div>
          </div>
          <div className="copyright">
            © 2026 New Learning Academy. All rights reserved.
          </div>
        </div>
      </footer>
      <ThemeToggleButton />
    </div>
  );
}

// Helper Component
const FeatureItem = ({ title, desc }: { title: string; desc: string }) => (
  <div className="cd-feature-item">
    <div className="cd-check-icon"><CheckCircle size={20} color="#10b981" /></div>
    <div><h4>{title}</h4><p>{desc}</p></div>
  </div>
);