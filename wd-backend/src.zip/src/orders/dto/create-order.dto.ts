import { Type } from 'class-transformer';
import { IsNumber } from 'class-validator';

export class CreateOrderDto {
  @Type(() => Number)
  @IsNumber()
  user_id: number;

  @Type(() => Number)
  @IsNumber()
  total_amount: number;
}